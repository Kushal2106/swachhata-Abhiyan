export class Complaint
{
    comp_id:number;
    type:string;
    image:string;
    description:string
}