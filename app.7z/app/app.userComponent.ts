import { Component,OnChanges, OnInit } from '@angular/core';
import { UserService } from './app.userservice';
import { User } from './app.user';

@Component({
    selector:'user-app',
    templateUrl: 'app.user.html'
})
export class UserComponent implements OnInit{

    users:User[];
    model:any={};
    user:any={"id":1008,"name":"ASDFFF","address.addr_id":109,"address.area":"Lemon","address.pincode":71414,"address.houseno":"23A","complaint.comp_id":101,"complaint.type":"drainage","complaint.image":"asas","complaint.description":"very bad"}

    constructor(private userService: UserService){
        console.log("In User Constructor");
    }

    ngOnInit(){
        console.log("in on init");
        this.userService.getAllUser().subscribe((data:User[])=>this.users=data);
        
    }
    addUser(){
        // console.log(this.model);

        this.userService.addAllUser(this.model).subscribe((data:any)=>console.log(data));
    }

}