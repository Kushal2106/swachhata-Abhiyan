export class InventoryComponent{
id:number;
name:string
}