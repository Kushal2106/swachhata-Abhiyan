export class Address
{
    addr_id:number;
    area:string;
    pincode:number;
    houseno:string
}