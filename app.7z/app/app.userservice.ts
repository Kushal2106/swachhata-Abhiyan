import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './app.user';


@Injectable({
    providedIn:'root'
})
export class UserService{
    opionts={
        headers: new HttpHeaders({
            'Access-Control-Allow-Headers':'Content-Type',
            'Access-Control-Allow-Methods':'GET,POST,OPTIONS',
            'Access-Control-Allow-oRIGIN':'*'
        })
    }

    constructor(private http:HttpClient){}

        getAllUser(){
           return this.http.get("http://localhost:9098/user/show");
    }

    addAllUser(user:any){
        console.log("product console..."+user);

        let input  = new FormData();
        
        input.append("id",user.id);
        input.append("name",user.name);
        input.append("address.addr_id",user.addressid);
        input.append("address.area",user.addressarea);
        input.append("address.pincode",user.addresspincode);
        input.append("address.houseno",user.addresshouseno);
        input.append("complaintList.comp_id",user.complaintcompid);
        input.append("complaintList.type",user.complainttype);
        input.append("complaintList.image",user.complaintimage);
        input.append("complaintList.description",user.complaintdescription);
        
        return this.http.post("http://localhost:9098/user/add",input);
    }

}