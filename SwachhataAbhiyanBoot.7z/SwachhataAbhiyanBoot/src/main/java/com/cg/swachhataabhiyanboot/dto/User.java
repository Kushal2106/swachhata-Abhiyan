package com.cg.swachhataabhiyanboot.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="user")
public class User {

	@Id
	@Column(name="user_id")
	private int id;
	@Column(name="user_name")
	private String name;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="addr_id")
	private Adddress address;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="user_id")
	private List<Complaint>complaintList;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(int id, String name, Adddress address, List<Complaint> complaintList) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.complaintList = complaintList;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Adddress getAddress() {
		return address;
	}
	public void setAddress(Adddress address) {
		this.address = address;
	}
	public List<Complaint> getComplaintList() {
		return complaintList;
	}
	public void setComplaintList(List<Complaint> complaintList) {
		this.complaintList = complaintList;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", address=" + address + ", complaintList=" + complaintList + "]";
	}
	
	
}
