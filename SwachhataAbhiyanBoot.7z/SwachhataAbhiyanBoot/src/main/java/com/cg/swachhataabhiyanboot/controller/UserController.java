package com.cg.swachhataabhiyanboot.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.cg.swachhataabhiyanboot.dto.User;
import com.cg.swachhataabhiyanboot.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserService service;
	/**
	 * Last Modified On 24/05/2019
	 *The following method is used for adding users, address and complaints
	 *@author krawani
	 *@param This method is used for adding users, address and complaints
	 *@return the users, address and complaints that we have added
	 */
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public ResponseEntity<User>addUserData(@ModelAttribute("user") User user)
	{
		User userRef=service.addUser(user);
		System.out.println(userRef);
		if(userRef==null)
		{
			return new ResponseEntity("user not added",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<User>(userRef,HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/show",method=RequestMethod.GET)
	public ResponseEntity<List<User>>showAllUser()
	{
		List<User> userList=service.showAll();
		if(userList.isEmpty())
		{
			return new ResponseEntity("No user to Show",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<User>>(userList,HttpStatus.OK);
		
	}
	/**
	 * Last Modified On 24/05/2019
	 *The following method is used for finding user details
	 *@author krawani
	 *@param This method is used for finding  details using user name that we have added already
	 *@return the user details 
	 */
	
	@RequestMapping(value="/searchuser",method=RequestMethod.GET)
	public ResponseEntity<List<User>> searchUser(@RequestParam("name") String name)
	{
		List<User> myList=service.searchName(name);
		System.out.println(myList);
		if(myList.isEmpty())
		{
			return new ResponseEntity("No user found with this name.",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<User>>(myList,HttpStatus.OK);
		
	}
	/**
	 * Last Modified On 24/05/2019
	 *The following method is used for finding user details
	 *@author krawani
	 *@param This method is used for finding  user details using area that we have added already
	 *@return the user details 
	 */
	@RequestMapping(value="/searchbyarea",method=RequestMethod.POST)
	public ResponseEntity<List<User>> searchByArea(@RequestParam("area") String area)
	{
		
		List<User> myListRef=new ArrayList<User>();
		List<User> myList=service.searchByArea(area);
		for(User user:myList)
		{
			if(area.equals(user.getAddress().getArea()))
			{
				myListRef.add(user);
			}
		}
		
		System.out.println(myList);
		if(myList.isEmpty())
		{
			return new ResponseEntity("No user in this area",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<User>>(myListRef,HttpStatus.OK);
		
	}
	
}
