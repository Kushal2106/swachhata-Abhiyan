package com.cg.swachhataabhiyanboot.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="address")
public class Adddress {

	@Id
	@Column(name="addr_id")
	private int id;
	@Column(name="addr_area")
	private String area;
	@Column(name="addr_pincode")
	private int pincode;
	@Column(name="addr_houseno")
	private String houseno;
	public Adddress() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Adddress(int id, String area, int pincode, String houseno) {
		super();
		this.id = id;
		this.area = area;
		this.pincode = pincode;
		this.houseno = houseno;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getHouseno() {
		return houseno;
	}
	public void setHouseno(String houseno) {
		this.houseno = houseno;
	}
	@Override
	public String toString() {
		return "Adddress [id=" + id + ", area=" + area + ", pincode=" + pincode + ", houseno=" + houseno + "]";
	}
	
}
