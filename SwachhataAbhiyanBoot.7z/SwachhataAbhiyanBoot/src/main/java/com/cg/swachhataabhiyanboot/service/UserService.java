package com.cg.swachhataabhiyanboot.service;

import java.util.List;

import com.cg.swachhataabhiyanboot.dto.User;

public interface UserService {

	public User addUser(User user);
	public List<User>searchName(String name);
	public List<User>searchByArea(String area);
	public List<User>showAll();
}
