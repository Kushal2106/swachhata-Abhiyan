package com.cg.swachhataabhiyanboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.swachhataabhiyanboot.dao.UserDao;
import com.cg.swachhataabhiyanboot.dto.User;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserDao  dao;
	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return dao.save(user);
	}

	@Override
	public List<User> searchName(String name) {
		// TODO Auto-generated method stub
		return  dao.findByName(name);
	}

	@Override
	public List<User> showAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

}
