package com.cg.swachhataabhiyanboot.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.swachhataabhiyanboot.dao.UserDao;
import com.cg.swachhataabhiyanboot.dto.User;

/**
 * Service layer Implementation
 * @author krawani
 * last update 25/05/2019
 */

@Service
public class UserServiceImpl implements UserService{

	/**
	 * this method is to add the data in user and pass it to Repository layer
	 */
	@Autowired
	UserDao  dao;
	
	static final Logger logger = Logger.getLogger(UserServiceImpl.class); 	

	/**
	 * Last Modified On 24/05/2019
	 *The following method is used for adding users, address and complaints
	 *@author krawani
	 *@param This method is used for adding users, address and complaints
	 *@return the users, address and complaints that we have added
	 */
	@Override
	public User addUser(User user) {
		PropertyConfigurator.configure("D:\\Users\\krawani\\Downloads\\SwachhataAbhiyanBoot\\src\\main\\resources\\log4j.properties"); 
		logger.info("User added successful");
		// TODO Auto-generated method stub
		return dao.save(user);
	}

	/**
	 * this method is used to take user keyword from the user and search details of the user
	 * return to repository layer
	 */
	@Override
	public List<User> searchName(String name) {
		PropertyConfigurator.configure("D:\\Users\\krawani\\Downloads\\SwachhataAbhiyanBoot\\src\\main\\resources\\log4j.properties"); 
		logger.info("User Search successful");
		// TODO Auto-generated method stub
		return  dao.findByName(name);
	}

	/**
	 * this method is used to show all the details
	 * 
	 */
	@Override
	public List<User> showAll() {
		PropertyConfigurator.configure("D:\\Users\\krawani\\Downloads\\SwachhataAbhiyanBoot\\src\\main\\resources\\log4j.properties"); 
		logger.info("User added successful");
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public List<User> searchByArea(String area) {
		PropertyConfigurator.configure("D:\\Users\\krawani\\Downloads\\SwachhataAbhiyanBoot\\src\\main\\resources\\log4j.properties"); 
		logger.info("Area Search successful");
		// TODO Auto-generated method stub
		return dao.findByArea(area);
	}

}
