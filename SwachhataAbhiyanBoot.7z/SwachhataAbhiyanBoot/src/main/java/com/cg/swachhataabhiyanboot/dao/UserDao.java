package com.cg.swachhataabhiyanboot.dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.swachhataabhiyanboot.dto.User;

public interface UserDao extends JpaRepository<User, Integer> {

  //  @Query("Select obj from User obj where obj.name=name" )
	public List<User>findByName( @Param("name")String name);
    @Query("Select u from User u")
    public List<User>findByArea(@Param("area")String area);
}
