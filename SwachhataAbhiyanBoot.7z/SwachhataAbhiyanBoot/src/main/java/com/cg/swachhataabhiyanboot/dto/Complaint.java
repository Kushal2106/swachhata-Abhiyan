package com.cg.swachhataabhiyanboot.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="complaint")
public class Complaint {

	@Id
	@Column(name="comp_id")
	private int id;
	@Column(name="comp_type")
	private String type;
	@Column(name="comp_image")
	private String image;
	@Column(name="comp_description")
	private String description;
	/*@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="user_id")
	private User user;*/
	
	public Complaint() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Complaint(int id, String type, String image, String description) {
		super();
		this.id = id;
		this.type = type;
		this.image = image;
		this.description = description;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Complaint [id=" + id + ", type=" + type + ", image=" + image + ", description=" + description + "]";
	}

	
	

	
	
}
